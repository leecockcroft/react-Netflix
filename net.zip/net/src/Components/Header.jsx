import React from 'react'

const Header=(props)=>{

return (
  <h2 className='header'>{props.name}</h2>
)


}


export default Header
